import { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Disc } from 'lucide-react';

// USER: SILAKAN PASTE LINK DROPBOX KAMU DI VARIABEL INI YA! 🌸
// Kode kami otomatis mengubah format link Dropbox biasa agar bisa diputar langsung.
const MUSIC_URL = "https://assets.mixkit.co/music/preview/mixkit-beautiful-dream-493.mp3";

const convertDropboxUrl = (url: string) => {
  if (!url) return '';
  let directUrl = url;
  if (directUrl.includes('dropbox.com')) {
    directUrl = directUrl.replace('www.dropbox.com', 'dl.dropboxusercontent.com');
    if (directUrl.includes('dl=0')) {
      directUrl = directUrl.replace('dl=0', 'raw=1');
    } else if (!directUrl.includes('raw=1') && !directUrl.includes('dl=1')) {
      directUrl += directUrl.includes('?') ? '&raw=1' : '?raw=1';
    }
  }
  return directUrl;
};

export default function BackgroundMusic() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const finalSrc = convertDropboxUrl(MUSIC_URL);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    // Set loop to true for continuous sweet ambiance
    audio.loop = true;

    // Browser blocks autoplay without user interaction, so we listen to first interaction
    const startAudio = () => {
      audio.play()
        .then(() => {
          setIsPlaying(true);
          cleanupEvents();
        })
        .catch((err) => {
          console.log("Autoplay blocked by browser. Awaiting manual interaction.", err);
        });
    };

    // Attach interaction events
    const events = ['click', 'touchstart', 'keydown', 'mousedown'];
    const cleanupEvents = () => {
      events.forEach(evt => document.removeEventListener(evt, startAudio));
    };

    events.forEach(evt => document.addEventListener(evt, startAudio));

    // Try to autoplay immediately
    audio.play()
      .then(() => {
        setIsPlaying(true);
        cleanupEvents();
      })
      .catch(() => {
        // Ignored - will await user interaction
      });

    return () => {
      cleanupEvents();
    };
  }, []);

  const handleMuteToggle = () => {
    if (audioRef.current) {
      const newMuted = !isMuted;
      audioRef.current.muted = newMuted;
      setIsMuted(newMuted);

      // If they unmute and audio is paused, try to play
      if (!newMuted && audioRef.current.paused) {
        audioRef.current.play()
          .then(() => setIsPlaying(true))
          .catch(err => console.log(err));
      }
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2 bg-white/90 backdrop-blur-md border border-[#f5d6d1] px-3 py-2 rounded-full shadow-lg transition-all hover:bg-white text-[#d97466]">
      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        src={finalSrc}
        preload="auto"
      />

      <div className="flex items-center gap-1.5 shrink-0">
        <Disc className={`w-4 h-4 text-[#d97466] ${isPlaying && !isMuted ? 'animate-spin' : 'animate-pulse'}`} style={{ animationDuration: '4s' }} />
        <span className="text-[10px] font-mono font-bold tracking-wider uppercase select-none hidden sm:inline">
          {isPlaying && !isMuted ? 'Alunan Cinta' : 'Lagu Dijeda'}
        </span>
      </div>

      <button
        type="button"
        onClick={handleMuteToggle}
        className="w-6 h-6 rounded-full bg-[#fff0f3] border border-[#f5d6d1]/50 flex items-center justify-center hover:bg-[#d97466] hover:text-white transition-colors cursor-pointer"
        title={isMuted ? "Bunyikan Musik" : "Senyapkan Musik"}
      >
        {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
      </button>
    </div>
  );
}
