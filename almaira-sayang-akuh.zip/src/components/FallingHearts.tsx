import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface HeartParticle {
  id: number;
  x: number;
  size: number;
  duration: number;
  delay: number;
  type: 'heart' | 'petal' | 'sparkle';
  color: string;
}

export default function FallingHearts() {
  const [particles, setParticles] = useState<HeartParticle[]>([]);

  useEffect(() => {
    // Generate static metadata for particles once to prevent infinite loops or rapid rebuilding
    const types: ('heart' | 'petal' | 'sparkle')[] = ['heart', 'petal', 'sparkle'];
    const colors = [
      '#d97466', // Terracotta
      '#e8c5c1', // Rose Gold
      '#fff0f3', // Pure luxury soft pink
      '#ffffff', // Elegant snow white
      '#ff949b', // Sweet cherry blush
    ];

    const initialParticles = Array.from({ length: 18 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100, // percentage of viewport width
      size: Math.random() * 14 + 10, // 10px to 24px
      duration: Math.random() * 10 + 8, // 8s to 18s
      delay: Math.random() * -15, // Negative delay so particles start midway on load
      type: types[Math.floor(Math.random() * types.length)],
      color: colors[Math.floor(Math.random() * colors.length)],
    }));

    setParticles(initialParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute opacity-60"
          style={{
            left: `${p.x}%`,
            top: '-20px',
            color: p.color,
          }}
          animate={{
            y: ['0vh', '108vh'],
            rotate: [0, 180, 360],
            x: [`${p.x}%`, `${p.x + (Math.random() * 10 - 5)}%`, `${p.x}%`],
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            delay: p.delay,
            ease: 'linear',
          }}
        >
          {p.type === 'heart' ? (
            <svg
              className="w-full h-full fill-current"
              style={{ width: p.size, height: p.size }}
              viewBox="0 0 24 24"
            >
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
          ) : p.type === 'petal' ? (
            <svg
              className="w-full h-full fill-current rotate-45"
              style={{ width: p.size - 2, height: p.size - 2 }}
              viewBox="0 0 24 24"
            >
              <path d="M12 2C12 2 4 10 4 14s4 8 8 8 8-4 8-8-8-12-8-12z" />
            </svg>
          ) : (
            <svg
              className="w-full h-full fill-current"
              style={{ width: p.size - 4, height: p.size - 4 }}
              viewBox="0 0 24 24"
            >
              <path d="M12 2l2.4 7.2 7.2 2.4-7.2 2.4-2.4 7.2-2.4-7.2-7.2-2.4 7.2-2.4z" />
            </svg>
          )}
        </motion.div>
      ))}
    </div>
  );
}
