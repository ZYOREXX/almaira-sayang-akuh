import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, MailOpen, Heart, Sparkles, RefreshCw } from 'lucide-react';
import { KissParticle } from '../types';

interface LoveLetterProps {
  onLetterOpenStateChange: (isOpen: boolean) => void;
  triggerGlobalKiss: () => void;
}

export default function LoveLetter({ onLetterOpenStateChange, triggerGlobalKiss }: LoveLetterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [localKisses, setLocalKisses] = useState<KissParticle[]>([]);

  const ASCII_ART = `###################################################################################################-
###################################################################################################-
###################################################################################################-
##------------------------++++---+#############################+-----------------------------+#####+
##----------------------+++++-+##################################+---------------------------+#####-
##---------------------++++-+#####################################+--------------------------+#####-
##--------------------+++++######################################+---------------------------+#####-
##-------------------++-+#######################################-----------------------------+#####+
##--------------------+##########################################-----------------------------#####-
##-------------------+###########################################+----------------------------#####+
##------------------+#############################################+------------------------+-+#####+
##-----------------+#######################+++++###################+---------------------+++-+#####+
##----------------+######################++---+++++++-+++############--------------------+++-+#####+
##----------------#####################++------+++++++################-------------------+++-+#####+
##---------------+####################++++------++++###################+-----------------+#+-+######
##---------------+##################++++++------+++#++++++++++##########+---------------++#+-+######
##---------------+#################+++++++-------+++----------############+--------------+#+++######
##---------------+#####################+++--------+++---------+#############+----------+++#+-+######
##-----------------++##############+##+++----------+++--------+#################++---++++##++#######
##------------------############++------------------+++--------+####################################
##-----------------+##########++----------------..-------------++###################################
##------------------+#########---+------------------+--++------++###################################
##------------------+###--+##-.---------------+--++##+++------++###################################
##-------------------+###--.-+-...-+----------++---------------++###################################
##-------------------+###-----+-...--------------------------++++###################################
##------------------++###---..----...-+--------------++++++##++++###################################
##------------------+####+---...--....--+--------++++#++---++++++###################################
##-----------------+#+####+---...--......--++++++---------+++++++###################################
##-----------------+#######+----..---.. ...---++++---++++##+++++########################++##########
##-----------------#+##+#####--------..........---+---------++++######################++++++########
##-----------------###++######----------..........---------+++######################++++++--+#######
##----------------###-+########+----------..........----+++########################+++++++++-+######
##----------------+#############+---+-------.......-------#########################+----------######
##-------------------+############+++++--------------------########################++---------######
##--------------------+##############+++++-----------------########+++##############++--------######
##------------------#+##+###############++++---------------+#######+++##############+++----.--######
##--------------------++########+++++++++++#++--------------+######+++##############++++---.--######
##------...------------++########++++#########++------------+######+++##############++++++----######
##+-----------..------+-+++########++++-+------++------------#######################+++++++---######
##+----------...----------+++######++-----------++-----------+######################++++++++--######
##------....--..-.----------++######+++-++++---+-++-----------+######################++++++++#######
##-.---...---.-....--.-------++#####++++--+++++---+-----------+#######################+++++++#######
##- ......---. ..-.....------+++#####+++--+++++----+-----------+######################+++++++#######
##-.....-----..........-------+######+-+-+--+++++--++----------++########################++++#######
##- .......---....------------+++#####+--------++++++-----------+########################++++#######
##. .... ..----..-------------++++####+---------+++++----------+++######################++++-+######
##- ....--.---.....-------------+++####+---------+++++----------+++################+++-++----+######
##-..---------........------+-----+####++---------++++---------+++++###############++++++++--+######
##-..---------....----------------+++###+----------++++---------++++################++++++++++######
##-..---.------...----------------++++##++----------++++----+-++++++#################+++++++++######
##- .----------...----------------+++++##+----------++++-+--+-+-+++++###############+++++++++#######
##--.----------.-...-------------+++++###+-----------+++++--+++++++++###############+#+++++++#######
##-..----------.-........----------++++##++----------++++++++++++++++###############+++++++++#######
##--.-.--------.........------------+++###+----------+++++++++++++++++################+++++++#######
##-. ...--.....-.......-------------+++###++---------++++++++++++++++#################++++++########
##-...-.  .....-......--------------++-+###++--------+++  ++++++++++++#######.  ######+#+#+#+#######
##-  .-.   ...--    .   -.  --   ---++- .#+  +----   .++  +. -  --  -##+   ##+ -# .- ++   +##+######
##-  ..   ....       .  -      .   +++-  #.  +---  -.  +  +   -   -  -   +  --  +       +  -########
##-  .--  --..   ..  .     -       ----  #.  +++-      +  +   +   +  .-     --  +  ##.     -########
##-  .--      .      -.   --      .+---      #++-      +  +   +   +  .      --  +  ##      -########
###++++#++++++##+++++##+++++##++++######++#+######++#++##+#++###+##++###++#######+#####++#+#########`;

  const messages = [
    {
      headline: "Hai Sayang, Ada Pesan Untukmu... 🤍",
      message: "Sejac pertama kali kamu hadir di hidupku, semua hal terasa menjadi jauh lebih indah. Terima kasih ya sudah selalu sabar, menemani, dan menjadi alasan di balik senyumku setiap hari. Aku beruntung bisa memilikimu di sisiku.",
      buttonText: "Klik Ini ✨"
    },
    {
      headline: "I Love You More Than Words Can Say 🌹",
      message: "Setiap langkah dan proses yang aku jalani saat ini, salah satu motivasi terbesarnya adalah untuk membangun masa depan yang baik bersamamu. Tetap sama-sama terus ya?",
      buttonText: "Satu lagi... 🌹"
    },
    {
      headline: "Selamanya, Insya Allah. 💕",
      message: "Tidak ada hal yang lebih membahagiakan selain tahu bahwa kita saling mendukung satu sama lain. Kamu berharga, hari ini, esok, dan seterusnya. Terima kasih sudah bersamaku.",
      buttonText: "Ulangi Kisah Kita 🔁"
    }
  ];

  const spawnLocalKisses = () => {
    // Spawn gorgeous kiss particles bursting from the center
    const texts = ["💋", "Mwah! 😘", "Cup! 💋", "Emuah! 💕", "Luv u! ❤️", "Chuu! 🌸", "Muacchh! 💋"];
    const newParticles: KissParticle[] = [];
    const baseId = Date.now();

    for (let i = 0; i < 18; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 4 + 3;
      newParticles.push({
        id: baseId + i,
        x: 50, // center percentages
        y: 45,
        velocity_x: Math.cos(angle) * speed,
        velocity_y: Math.sin(angle) * speed - 2, // lean upwards
        scale: Math.random() * 0.7 + 0.7,
        rotation: Math.random() * 60 - 30,
        text: texts[Math.floor(Math.random() * texts.length)]
      });
    }

    setLocalKisses((prev) => [...prev, ...newParticles]);

    // Cleanup particles after 1.8 seconds to maintain performance
    setTimeout(() => {
      setLocalKisses((prev) => prev.filter((p) => !newParticles.find((x) => x.id === p.id)));
    }, 1800);
  };

  const handleOpen = () => {
    setIsOpen(true);
    onLetterOpenStateChange(true);
    triggerGlobalKiss();
    spawnLocalKisses();
  };

  const handleNext = () => {
    triggerGlobalKiss();
    spawnLocalKisses();
    if (step < messages.length - 1) {
      setStep(step + 1);
    } else {
      setStep(0); // Reset or stay
    }
  };

  return (
    <div className="w-full flex flex-col items-center relative">
      
      {/* 1. Mwah Kiss Burst Particles Container */}
      <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden rounded-3xl">
        <AnimatePresence>
          {localKisses.map((kp) => (
            <motion.div
              key={kp.id}
              initial={{ opacity: 1, scale: 0.1, x: `50%`, y: `45%`, rotate: 0 }}
              animate={{
                opacity: [1, 1, 0.8, 0],
                scale: [0.1, kp.scale, kp.scale * 1.3, kp.scale * 0.8],
                x: `calc(50% + ${kp.velocity_x * 40}px)`,
                y: `calc(45% + ${kp.velocity_y * 40}px)`,
                rotate: kp.rotation * 3
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.4, ease: "easeOut" }}
              className="absolute select-none font-sans font-black pointer-events-none text-[#d97466] text-shadow-sm flex items-center gap-1 bg-white/90 border border-pink-100 px-2 py-0.5 rounded-full shadow-md text-xs"
              style={{
                left: '0%',
                top: '0%',
                transform: 'translate(-50%, -50%)'
              }}
            >
              <span>{kp.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <AnimatePresence mode="wait">
        {!isOpen ? (
          /* Envelope Cover Design in Ivory Pink style */
          <motion.div
            key="envelope"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 20 }}
            className="w-full max-w-xl bg-white/95 border border-[#f5d6d1] rounded-3xl p-8 shadow-2xl flex flex-col items-center text-center gap-6 relative overflow-hidden"
          >
            {/* Decors */}
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-[#d97466] via-[#e8c5c1] to-[#d97466]" />
            <div className="absolute -right-16 -top-16 w-32 h-32 rounded-full bg-[#fff2f4] blur-xl" />
            <div className="absolute -left-16 -bottom-16 w-32 h-32 rounded-full bg-[#fff2f4] blur-xl" />

            <div className="w-20 h-20 bg-gradient-to-br from-[#d97466] to-[#e8c5c1] rounded-full flex items-center justify-center shadow-lg transform -rotate-6 animate-bounce">
              <Mail className="w-10 h-10 text-white" />
            </div>

            <div className="space-y-2">
              <h2 className="font-serif text-2xl sm:text-3xl font-black text-[#5c4436] tracking-tight">
                Surat Cinta Untukmu ✉️
              </h2>
              <p className="font-sans text-sm text-[#4a3525]/80 max-w-sm mx-auto">
                Ditulis dengan penuh ketulusan, rasa sayang yang mendalam, dan harapan indah masa depan bersama.
              </p>
            </div>

            <button
              type="button"
              onClick={handleOpen}
              className="mt-2 bg-gradient-to-r from-[#d97466] to-[#e8c5c1] text-white font-extrabold py-3.5 px-8 rounded-full shadow-lg text-sm font-sans flex items-center gap-2 hover:brightness-105 active:scale-95 transition-all duration-300 cursor-pointer border border-[#fff2f4]"
            >
              <MailOpen className="w-4 h-4" />
              Buka Surat Ini ✨
            </button>
          </motion.div>
        ) : (
          /* Opened Letter View */
          <motion.div
            key="letter"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 80 }}
            className="w-full flex flex-col items-center gap-6"
          >
            {/* ASCII CONTAINER WITH FLUID TEXT SIZE FOR RESPONSIVENESS AND TEXT COLOR PINK/TERRACOTTA */}
            <div className="w-full bg-[#fff4f5] border border-[#f5d6d1] overflow-hidden rounded-2xl p-3 sm:p-5 shadow-inner flex justify-center text-[#d97466] relative">
              <div className="absolute top-2 right-2 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#d97466] animate-spin" style={{ animationDuration: '6s' }} />
                <span className="text-[9px] font-mono text-[#d97466]/70 tracking-widest uppercase font-bold">RETRATA ART WIFE</span>
              </div>
              
              <div className="overflow-x-auto w-full select-none cursor-default flex justify-center max-w-full">
                <pre 
                  className="font-mono text-[1.1vw] sm:text-[6.8px] md:text-[8.5px] lg:text-[9px] leading-[1.05] tracking-tighter whitespace-pre py-2 scrollbar-thin select-none"
                  style={{
                    fontFamily: '"JetBrains Mono", "Courier New", Courier, monospace',
                    fontWeight: 900
                  }}
                >
                  {ASCII_ART}
                </pre>
              </div>
            </div>

            {/* Letter Content Envelope Paper in Cream/Ivory tone with Pink Accent */}
            <motion.div
              layout
              className="w-full max-w-2xl bg-white border border-[#f5d6d1] p-6 sm:p-8 rounded-2xl shadow-xl backdrop-blur-md relative"
            >
              <div className="absolute top-3 right-4 flex gap-1.5">
                {Array.from({ length: 3 }).map((_, idx) => (
                  <Heart 
                    key={idx} 
                    className="w-4 h-4 text-[#d97466]" 
                    fill={idx <= step ? "currentColor" : "none"} 
                  />
                ))}
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4 pt-2"
                >
                  <h3 className="font-serif text-xl sm:text-2xl font-black text-[#4a3525] tracking-tight">
                    {messages[step].headline}
                  </h3>
                  
                  <p className="font-sans text-sm sm:text-base leading-relaxed text-[#4a3525]/90 whitespace-pre-wrap font-medium">
                    {messages[step].message}
                  </p>
                </motion.div>
              </AnimatePresence>

              {/* Step indicator bar */}
              <div className="h-1 bg-[#fff0f3] rounded-full mt-6 overflow-hidden border border-[#f5d6d1]/10">
                <div 
                  className="bg-gradient-to-r from-[#d97466] to-[#e8c5c1] h-full transition-all duration-300"
                  style={{ width: `${((step + 1) / messages.length) * 100}%` }}
                />
              </div>

              <div className="flex justify-between items-center mt-6 pt-4 border-t border-[#f5d6d1]">
                <span className="font-mono text-xs text-[#4a3525]/70 font-semibold">
                  Langkah {step + 1} dari {messages.length}
                </span>

                <button
                  type="button"
                  onClick={handleNext}
                  className="bg-[#d97466] hover:bg-[#e8c5c1] text-white font-bold py-2 px-6 rounded-full text-xs font-sans tracking-tight transition-all active:scale-95 duration-300 flex items-center gap-1 cursor-pointer shadow-md"
                >
                  {step === messages.length - 1 ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
                      {messages[step].buttonText}
                    </>
                  ) : (
                    messages[step].buttonText
                  )}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
