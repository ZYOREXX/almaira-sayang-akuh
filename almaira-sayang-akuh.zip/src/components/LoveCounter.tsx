import { useState, useEffect } from 'react';
import { Heart, Clock, Pencil, Check, X } from 'lucide-react';

export default function LoveCounter() {
  // Try loading saved date from localStorage, default to a romantic date (e.g. November 25, 2024)
  const [anniversaryStr, setAnniversaryStr] = useState(() => {
    return localStorage.getItem('anniversary_date') || '2024-11-25T00:00:00';
  });
  
  const [isEditing, setIsEditing] = useState(false);
  const [tempDate, setTempDate] = useState('');
  const [elapsed, setElapsed] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Clock effect ticking every second
  useEffect(() => {
    const calculateTime = () => {
      const start = new Date(anniversaryStr).getTime();
      const now = new Date().getTime();
      const difference = now - start;

      if (difference <= 0) {
        setElapsed({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const msec = difference;
      const hh = Math.floor(msec / 1000 / 60 / 60);
      const days = Math.floor(hh / 24);
      const hours = hh % 24;
      const minutes = Math.floor(msec / 1000 / 60) % 60;
      const seconds = Math.floor(msec / 1000) % 60;

      setElapsed({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);

    return () => clearInterval(interval);
  }, [anniversaryStr]);

  const saveDate = () => {
    if (!tempDate) return;
    const isoDateTime = `${tempDate}T00:00:00`;
    localStorage.setItem('anniversary_date', isoDateTime);
    setAnniversaryStr(isoDateTime);
    setIsEditing(false);
  };

  const getDayFormatted = () => {
    const d = new Date(anniversaryStr);
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-white/95 backdrop-blur-md border border-[#f5d6d1] p-5 rounded-2xl w-full shadow-xl relative overflow-hidden">
      {/* Decorative pulse hearts */}
      <div className="absolute top-2 right-2 opacity-5 animate-pulse">
        <Heart className="w-16 h-16 text-[#d97466]" fill="currentColor" />
      </div>

      <div className="flex justify-between items-center mb-4">
        <h3 className="font-serif text-lg text-[#4a3525] font-extrabold flex items-center gap-2">
          <Clock className="w-5 h-5 text-[#d97466] animate-spin" style={{ animationDuration: '10s' }} />
          Waktu Kisah Kita
        </h3>

        {!isEditing ? (
          <button 
            type="button"
            onClick={() => {
              setTempDate(anniversaryStr.split('T')[0]);
              setIsEditing(true);
            }} 
            className="text-[10px] font-mono text-[#d97466] hover:text-[#4a3525] flex items-center gap-1 bg-[#fff0f3] px-3 py-1 rounded-full border border-[#f5d6d1] transition-all cursor-pointer"
          >
            <Pencil className="w-2.5 h-2.5" />
            Atur Tanggal Jadian 🌹
          </button>
        ) : (
          <div className="flex items-center gap-1">
            <button 
              type="button"
              onClick={saveDate}
              className="text-xs bg-[#d97466] text-white p-1 rounded-full hover:bg-[#e8c5c1] transition-all cursor-pointer"
              title="Simpan"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
            <button 
              type="button"
              onClick={() => setIsEditing(false)}
              className="text-xs bg-white text-[#4a3525] border border-[#f5d6d1] p-1 rounded-full hover:bg-neutral-100 transition-all cursor-pointer"
              title="Batal"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {isEditing ? (
        <div className="mb-4 bg-[#fff8f8] p-3 rounded-xl border border-[#f5d6d1]">
          <label className="block text-xs text-[#4a3525]/80 mb-1.5 font-mono">
            Kapan pertama kali kalian saling memiliki?
          </label>
          <input 
            type="date"
            value={tempDate}
            onChange={(e) => setTempDate(e.target.value)}
            className="w-full bg-white border border-[#f5d6d1] text-[#4a3525] text-sm rounded-lg p-2 font-mono focus:ring-1 focus:ring-[#d97466] outline-none"
          />
        </div>
      ) : (
        <p className="text-xs text-[#4a3525]/70 mb-4 font-mono">
          Sejak hari istimewa kita: <span className="text-[#d97466] font-bold">{getDayFormatted()}</span> 🤍
        </p>
      )}

      {/* Grid displays inside Pink/Ivory crystal capsules */}
      <div className="grid grid-cols-4 gap-2.5 text-center">
        {/* Days */}
        <div className="bg-[#fff8f8] rounded-xl p-2.5 border border-[#f5d6d1]/60 hover:border-[#d97466]/40 transition-all shadow-sm">
          <div className="font-serif text-2xl font-black text-[#d97466] select-all">
            {elapsed.days}
          </div>
          <div className="text-[10px] font-mono tracking-wider text-[#4a3525]/70 mt-1 uppercase font-bold">
            Hari
          </div>
        </div>

        {/* Hours */}
        <div className="bg-[#fff8f8] rounded-xl p-2.5 border border-[#f5d6d1]/60 hover:border-[#d97466]/40 transition-all shadow-sm">
          <div className="font-serif text-2xl font-black text-[#4a3525] select-all">
            {elapsed.hours.toString().padStart(2, '0')}
          </div>
          <div className="text-[10px] font-mono tracking-wider text-[#4a3525]/70 mt-1 uppercase font-bold">
            Jam
          </div>
        </div>

        {/* Minutes */}
        <div className="bg-[#fff8f8] rounded-xl p-2.5 border border-[#f5d6d1]/60 hover:border-[#d97466]/40 transition-all shadow-sm">
          <div className="font-serif text-2xl font-black text-[#4a3525] select-all">
            {elapsed.minutes.toString().padStart(2, '0')}
          </div>
          <div className="text-[10px] font-mono tracking-wider text-[#4a3525]/70 mt-1 uppercase font-bold">
            Menit
          </div>
        </div>

        {/* Seconds */}
        <div className="bg-[#fff8f8] rounded-xl p-2.5 border border-[#f5d6d1]/60 hover:border-[#d97466]/40 transition-all shadow-sm">
          <div className="font-serif text-2xl font-black text-[#d97466] select-all animate-pulse">
            {elapsed.seconds.toString().padStart(2, '0')}
          </div>
          <div className="text-[10px] font-mono tracking-wider text-[#4a3525]/70 mt-1 uppercase font-bold">
            Detik
          </div>
        </div>
      </div>
    </div>
  );
}
