import { useState, useEffect, ChangeEvent } from 'react';
import { motion } from 'motion/react';
import { Camera, RefreshCw, Upload, Heart, Sparkles } from 'lucide-react';

interface PolaroidProps {
  id: string;
  defaultTitle: string;
  defaultImage: string;
  rotation: string;
  scale?: number;
}

const DEFAULT_POLAROID_DATA: PolaroidProps[] = [
  {
    id: 'polaroid_1',
    defaultTitle: 'Senyum Manismu ✨',
    defaultImage: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80',
    rotation: '-rotate-6 hover:-rotate-2',
  },
  {
    id: 'polaroid_2',
    defaultTitle: 'Kehangatan Matamu 🤍',
    defaultImage: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
    rotation: 'rotate-1 hover:rotate-3 scale-105',
  },
  {
    id: 'polaroid_3',
    defaultTitle: 'Masa Depan Bersamamu 🌹',
    defaultImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    rotation: 'rotate-6 hover:rotate-2',
  }
];

export default function PolaroidGallery() {
  const [images, setImages] = useState<Record<string, string>>({});

  useEffect(() => {
    // Load saved images from localStorage
    const saved: Record<string, string> = {};
    DEFAULT_POLAROID_DATA.forEach((item) => {
      const stored = localStorage.getItem(`polaroid_img_${item.id}`);
      if (stored) {
        saved[item.id] = stored;
      }
    });
    setImages(saved);
  }, []);

  const handleImageUpload = (id: string, e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2.5 * 1024 * 1024) {
      alert("Maaf sayang, ukuran foto terlalu besar (maksimal 2.5MB) agar loading-nya tetap cepat ya! 🤍");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        localStorage.setItem(`polaroid_img_${id}`, base64);
        setImages((prev) => ({
          ...prev,
          [id]: base64,
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const resetImage = (id: string) => {
    localStorage.removeItem(`polaroid_img_${id}`);
    setImages((prev) => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };

  return (
    <div className="w-full flex flex-col items-center gap-12 py-6">
      {/* Elegance Header Inspired by LEEMA web layout */}
      <div className="text-center max-w-2xl px-4 space-y-4">
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-center gap-2"
        >
          <span className="w-8 h-[1px] bg-[#d97466]/40" />
          <span className="text-xs uppercase tracking-widest font-mono text-[#d97466] font-bold flex items-center gap-1">
            <Heart className="w-3 h-3 text-[#d97466] fill-[#d97466]" /> Galeri Foto Abadi
          </span>
          <span className="w-8 h-[1px] bg-[#d97466]/40" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-serif text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#4a3525] italic leading-tight"
        >
          Setiap detik terasa <span className="text-[#d97466]">sempurna</span> bersamamu.
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-sans text-sm sm:text-base text-[#4a3525]/85 leading-relaxed"
        >
          Setiap sudut di laman ini baru akan terasa hidup saat dihiasi oleh senyumanmu. 📸✨
        </motion.p>
      </div>

      {/* Polaroid Items grid - matches the design of LEEMA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12 max-w-5xl px-6 w-full pt-4">
        {DEFAULT_POLAROID_DATA.map((p, index) => {
          const currentImg = images[p.id] || p.defaultImage;
          return (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 40, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ 
                type: 'spring', 
                stiffness: 70, 
                damping: 18, 
                delay: index * 0.15 
              }}
              className={`flex flex-col items-center justify-center transition-all duration-500 cursor-default ${p.rotation}`}
            >
              {/* Actual Polaroid Card Body */}
              <div className="bg-white p-4 pb-6 rounded-sm shadow-2xl border border-neutral-100/80 w-full max-w-[280px] sm:max-w-[290px] relative group overflow-hidden flex flex-col items-center">
                
                {/* Decorative Pin Button style */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-[#d97466]/80 border-2 border-white shadow-md z-10" />

                {/* Polaroid Square Frame for image */}
                <div className="w-full aspect-square bg-slate-50 relative overflow-hidden rounded-sm border border-neutral-200/40 shadow-inner">
                  <img
                    src={currentImg}
                    alt={p.defaultTitle}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 select-none"
                  />

                  {/* Elegant overlay shade for inputs */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center items-center gap-2">
                    <label className="bg-white/95 hover:bg-[#d97466] hover:text-white text-[#4a3525] text-xs font-mono font-bold py-2 px-4 rounded-full shadow-lg cursor-pointer flex items-center gap-1.5 transition-all active:scale-95 duration-200">
                      <Camera className="w-3.5 h-3.5" />
                      Ganti Foto
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(p.id, e)}
                        className="hidden"
                      />
                    </label>

                    {images[p.id] && (
                      <button
                        type="button"
                        onClick={() => resetImage(p.id)}
                        className="bg-red-500/90 hover:bg-red-650 text-white text-[10px] font-mono py-1 px-3 rounded-full transition-all active:scale-95"
                        title="Kembalikan default"
                      >
                        Hapus Foto
                      </button>
                    )}
                  </div>
                </div>

                {/* Hand-written text label area at bottom of Polaroid */}
                <div className="w-full pt-4 pb-1 text-center font-serif text-lg tracking-wide text-[#5c4436] font-semibold flex flex-col items-center gap-0.5 select-none">
                  <span className="font-serif italic font-medium">
                    {p.defaultTitle}
                  </span>
                  <div className="flex justify-center items-center gap-1 text-[10px] font-mono text-neutral-400 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Sparkles className="w-2.5 h-2.5 text-[#d97466]" />
                    <span>simpan offline</span>
                  </div>
                </div>

                {/* Glow ribbon at the corner */}
                <div className="absolute -right-12 -top-12 w-24 h-24 bg-[#d97466]/5 rounded-full blur-xl pointer-events-none group-hover:bg-[#d97466]/10 transition-colors" />
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
