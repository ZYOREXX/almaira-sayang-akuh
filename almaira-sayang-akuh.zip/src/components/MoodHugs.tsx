import { useState } from 'react';
import type { ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Smile, Coffee, Heart, HeartCrack, Sparkles } from 'lucide-react';

type MoodType = 'happy' | 'tired' | 'sad' | 'normal' | null;

interface MoodOption {
  type: MoodType;
  label: string;
  emoji: string;
  color: string;
  icon: ReactNode;
  responseHeadline: string;
  responseBody: string;
  virtualGiftName: string;
  virtualGiftEmoji: string;
}

export default function MoodHugs() {
  const [selectedMood, setSelectedMood] = useState<MoodType>(null);

  const moods: MoodOption[] = [
    {
      type: 'happy',
      label: 'Bahagia',
      emoji: '🌸',
      color: 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100/50',
      icon: <Smile className="w-4 h-4 text-emerald-500" />,
      responseHeadline: 'Yay! Aku Sangat Senang Mendengarnya! 🥰',
      responseBody: 'Melihatmu bahagia atau tahu bahwa harimu berjalan lancar adalah hal terbaik bagiku. Senyummu itu selalu berhasil menerangi seluruh duniaku!',
      virtualGiftName: 'Bunga Tulip Virtual',
      virtualGiftEmoji: '🌷'
    },
    {
      type: 'tired',
      label: 'Lelah',
      emoji: '☕',
      color: 'bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100/50',
      icon: <Coffee className="w-4 h-4 text-amber-500" />,
      responseHeadline: 'Sini Peluk Erat... Kamu Hebat! 🫂',
      responseBody: 'Terima kasih ya sudah bertahan dan melangkah sejauh ini hari ini. Kamu sudah melakukan yang terbaik. Sekarang, taruh HPmu sebentar, pejamkan mata, letihmu biar aku temani pelan-pan ya.',
      virtualGiftName: 'Cokelat Hangat',
      virtualGiftEmoji: '☕🍫'
    },
    {
      type: 'sad',
      label: 'Sedih / Kangen',
      emoji: '🧸',
      color: 'bg-rose-50 border-[#f5d6d1] text-[#d97466] hover:bg-[#fff0f3]',
      icon: <HeartCrack className="w-4 h-4 text-[#d97466]" />,
      responseHeadline: 'Jangan Sedih, Sayang. Aku Ada di Sini... 🤍',
      responseBody: 'Kuharap aku bisa berada di sana sekarang untuk memelukmu erat. Tarik napas dalam-dalam ya, rindu ini juga milikku. Inget, selelah atau sesedih apa pun harimu, kamu punya telinga yang selalu siap mendengarkan di sini.',
      virtualGiftName: 'Selimut Hangat & Beruang Virtual',
      virtualGiftEmoji: '🧸✨'
    },
    {
      type: 'normal',
      label: 'Biasa Saja',
      emoji: '🍃',
      color: 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100',
      icon: <Sparkles className="w-4 h-4 text-stone-500" />,
      responseHeadline: 'Semoga Harimu Menyenangkan! ☀️',
      responseBody: 'Hari biasa juga penuh dengan hal-hal kecil yang layak disyukuri. Jangan lupa terhidrasi dengan baik, makan makanan lezat, dan kirim pesan singkat kepadaku sesekali ya!',
      virtualGiftName: 'Bintang Keberuntungan',
      virtualGiftEmoji: '⭐️'
    }
  ];

  const currentMoodObj = moods.find(m => m.type === selectedMood);

  return (
    <div className="bg-white/95 backdrop-blur-md border border-[#f5d6d1] p-5 rounded-2xl w-full shadow-xl">
      <h3 className="font-serif text-lg text-[#4a3525] font-extrabold flex items-center gap-2 mb-1">
        <Heart className="w-5 h-5 text-[#d97466] fill-[#d97466]/10 animate-pulse" />
        Bagaimana Kabarmu Hari Ini?
      </h3>
      <p className="text-xs text-[#4a3525]/60 font-mono mb-4">
        Ceritakan perasaanmu hari ini kepada mas/aku...
      </p>

      {/* Grid of buttons designed beautifully */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
        {moods.map((m) => (
          <button
            key={m.type}
            type="button"
            onClick={() => setSelectedMood(m.type)}
            className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl border text-xs font-mono font-bold transition-all duration-300 hover:scale-[1.03] active:scale-95 cursor-pointer ${
              selectedMood === m.type 
                ? `${m.color} ring-1 ring-[#d97466] shadow-sm` 
                : 'bg-white border-neutral-200/65 hover:border-[#f5d6d1] text-[#4a3525]/80 hover:bg-[#fffcfc]'
            }`}
          >
            <span>{m.emoji}</span>
            <span>{m.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {selectedMood && currentMoodObj && (
          <motion.div
            key={selectedMood}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="bg-[#fffcfc] rounded-xl p-4 border border-[#f5d6d1]/60 shadow-inner"
          >
            {/* Header */}
            <h4 className="font-serif text-sm font-extrabold text-[#4a3525] mb-1.5 flex items-center gap-1.5">
              {currentMoodObj.icon}
              {currentMoodObj.responseHeadline}
            </h4>

            {/* Paragraph body */}
            <p className="font-sans text-xs text-[#4a3525]/90 mb-3 leading-relaxed">
              {currentMoodObj.responseBody}
            </p>

            {/* Virtual gift badge */}
            <div className="flex items-center gap-2 bg-[#fff1f2] border border-[#f5d6d1]/40 px-3 py-1.5 rounded-lg w-max text-[10px] font-mono shadow-sm">
              <span className="text-xs">{currentMoodObj.virtualGiftEmoji}</span>
              <span className="text-[#d97466] font-semibold">Hadiah hangat untukmu: </span>
              <span className="text-[#4a3525] font-black">{currentMoodObj.virtualGiftName}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
