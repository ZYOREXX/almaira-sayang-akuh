export interface LoveMessageStep {
  headline: string;
  message: string;
  buttonText: string;
}

export type PartnerMood = 'happy' | 'tired' | 'sad' | 'normal';

export interface LoveQuote {
  id: number;
  text: string;
  author?: string;
}

export interface KissParticle {
  id: number;
  x: number;
  y: number;
  velocity_x: number;
  velocity_y: number;
  scale: number;
  rotation: number;
  text: string;
}
