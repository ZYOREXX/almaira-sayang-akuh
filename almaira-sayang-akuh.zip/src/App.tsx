import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, MessageSquareHeart, Pencil, Check, Quote, RefreshCw } from 'lucide-react';

import FallingHearts from './components/FallingHearts';
import BackgroundMusic from './components/BackgroundMusic';
import LoveCounter from './components/LoveCounter';
import MoodHugs from './components/MoodHugs';
import LoveLetter from './components/LoveLetter';
import PolaroidGallery from './components/PolaroidGallery';
import { KissParticle } from './types';

const LOVE_QUOTES = [
  "Dalam tiap senyummu, aku menemukan kembali alasan mengapa masa depan pantas diperjuangkan.",
  "Terima kasih sudah lahir ke dunia ini, dan terima kasih sudah memilih berjalan bersamaku menghadapi segala cuaca.",
  "Bersamamu, rumah bukan lagi sekadar bangunan fisik, melainkan sepasang mata teduh dan pelukan yang menenangkan badai.",
  "Secangkir cokelat hangat di sore gerimis masih kalah menenangkan dibanding pesan singkatmu yang menanyakan kabarku.",
  "Kamu adalah bait rasa paling indah yang pernah takdir tuliskan di dalam lembar perjalanan hidupku.",
  "Aku mencintaimu bukan hanya karena siapa dirimu, melainkan karena bagaimana aku merasa utuh ketika berada di sisimu."
];

export default function App() {
  const [nickname, setNickname] = useState(() => {
    return localStorage.getItem('partner_nickname') || 'Sayang';
  });
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState('');
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  const [greeting, setGreeting] = useState('Halo');
  const [isLetterOpen, setIsLetterOpen] = useState(false);
  const [globalKisses, setGlobalKisses] = useState<KissParticle[]>([]);

  // Time-based greetings & quote rotations
  useEffect(() => {
    const updateTimeGreetings = () => {
      const hour = new Date().getHours();
      if (hour >= 5 && hour < 11) {
        setGreeting('Selamat Pagi');
      } else if (hour >= 11 && hour < 15) {
        setGreeting('Selamat Siang');
      } else if (hour >= 15 && hour < 18) {
        setGreeting('Selamat Sore');
      } else {
        setGreeting('Selamat Malam');
      }
    };

    updateTimeGreetings();
    // Pick a random quote on mount
    setCurrentQuoteIndex(Math.floor(Math.random() * LOVE_QUOTES.length));
    
    // Check every hour
    const timer = setInterval(updateTimeGreetings, 3600000);
    return () => clearInterval(timer);
  }, []);

  const saveNickname = () => {
    const trimmed = tempName.trim();
    if (trimmed) {
      localStorage.setItem('partner_nickname', trimmed);
      setNickname(trimmed);
    }
    setIsEditingName(false);
  };

  const rotateQuote = () => {
    const nextIndex = (currentQuoteIndex + 1) % LOVE_QUOTES.length;
    setCurrentQuoteIndex(nextIndex);
    triggerGlobalKiss();
  };

  const triggerGlobalKiss = () => {
    const texts = ["💋", "Muachh! 😘", "Emuah! 💖", "Luv u! 💕", "Kiss! 🌸", "Cup! 😘", "XOXO 💋"];
    const newKisses: KissParticle[] = [];
    const baseId = Date.now() + Math.random();

    // Spawn 15 screen-wide floating kiss particles
    for (let i = 0; i < 15; i++) {
      newKisses.push({
        id: baseId + i,
        x: Math.random() * 80 + 10, // random screen coordinates
        y: Math.random() * 60 + 20,
        velocity_x: Math.random() * 4 - 2,
        velocity_y: -Math.random() * 3 - 2, // always floating up
        scale: Math.random() * 0.8 + 0.8,
        rotation: Math.random() * 90 - 45,
        text: texts[Math.floor(Math.random() * texts.length)]
      });
    }

    setGlobalKisses((prev) => [...prev, ...newKisses]);

    // Clean up particles
    setTimeout(() => {
      setGlobalKisses((prev) => prev.filter((k) => !newKisses.find((x) => x.id === k.id)));
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-tr from-[#fdfbf7] via-[#fff5f6] to-[#fff0f3] text-[#4a3525] font-sans antialiased relative px-4 py-8 sm:px-6 md:py-12 overflow-x-hidden flex flex-col justify-between selection:bg-[#f5d6d1] selection:text-[#d97466]">
      {/* 1. Animated falling heart and snowflake sparkles */}
      <FallingHearts />
      
      {/* Background Autplay Music element */}
      <BackgroundMusic />

      {/* 2. Absolute Screen Kiss Effect Overlays */}
      <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
        <AnimatePresence>
          {globalKisses.map((k) => (
            <motion.div
              key={k.id}
              initial={{ opacity: 0, scale: 0.1, y: `${k.y}vh`, x: `${k.x}vw`, rotate: 0 }}
              animate={{
                opacity: [0, 1, 1, 0.7, 0],
                scale: [0.1, k.scale, k.scale * 1.2, k.scale * 1.4, k.scale * 0.5],
                y: [`${k.y}vh`, `${k.y - 12}vh`],
                x: [`${k.x}vw`, `${k.x + k.velocity_x * 2}vw`],
                rotate: [0, k.rotation, k.rotation * 2]
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.8, ease: "easeOut" }}
              className="absolute pointer-events-none select-none flex items-center gap-1.5 bg-white/95 border border-[#f5d6d1] p-2.5 rounded-full shadow-lg text-[13px] font-mono tracking-tight font-black text-[#d97466]"
              style={{
                left: 0,
                top: 0,
                transform: 'translate(-50%, -50%)'
              }}
            >
              <span>{k.text}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* 3. Pure Content Shell Container */}
      <div className="max-w-6xl mx-auto w-full z-10 flex flex-col gap-8 md:gap-12 flex-grow">
        
        {/* Row 1: Header Brand Component */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#f5d6d1]/80 pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1 px-3 rounded-full bg-white/95 border border-[#f5d6d1] text-[10px] uppercase font-mono tracking-widest text-[#d97466] font-bold flex items-center gap-1 shadow-sm">
                <Heart className="w-2.5 h-2.5 animate-pulse text-[#d97466] fill-[#d97466]" /> 
                Melodi Asmara Abadi
              </span>
            </div>
            
            <div className="flex items-baseline flex-wrap gap-2 pt-1">
              <h1 className="font-serif text-3xl sm:text-4xl font-black tracking-tight text-[#4a3525] italic">
                {greeting},
              </h1>
              
              {/* Inline nickname editor */}
              {!isEditingName ? (
                <div className="flex items-center gap-1.5 group cursor-pointer" onClick={() => {
                  setTempName(nickname);
                  setIsEditingName(true);
                }}>
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#d97466] border-b-2 border-dashed border-[#f5d6d1] hover:border-[#d97466] transition-colors pb-0.5">
                    {nickname}!
                  </span>
                  <button
                    type="button"
                    className="text-[#d97466]/80 hover:text-[#d97466] transition-all p-1"
                    title="Ubah Panggilan"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 bg-white border border-[#f5d6d1] px-2.5 rounded-lg py-1 shadow-md">
                  <input
                    type="text"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    maxLength={15}
                    className="bg-transparent border-none text-[#d97466] font-serif text-2xl font-bold focus:ring-0 outline-none w-28 placeholder:text-[#d97466]/30"
                    placeholder="Nama sayang"
                    onKeyDown={(e) => e.key === 'Enter' && saveNickname()}
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={saveNickname}
                    className="p-1 text-[#d97466] hover:text-[#4a3525] cursor-pointer"
                    title="Simpan"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
            <p className="text-xs text-[#4a3525]/75 font-mono">
              Ruang cinta romantis khusus dirancang untuk merayakan duniaku: Kamu. 💖
            </p>
          </div>

          {/* Mini pulse status */}
          <div className="bg-white/95 border border-[#f5d6d1] py-2 px-4 rounded-full flex items-center gap-2 max-w-max self-start md:self-center font-mono text-[10px] shadow-sm">
            <span className="h-2.5 w-2.5 rounded-full bg-[#d97466] animate-pulse" />
            <span className="text-[#4a3525] font-bold">Roda Cinta Berputar Hangat</span>
          </div>
        </header>

        {/* Polaroid Board section - Inspired by LEEMA web layout design */}
        <div className="w-full">
          <PolaroidGallery />
        </div>

        {/* Dynamic Tips alert */}
        {!isLetterOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 border border-[#f5d6d1] rounded-2xl p-4 text-xs flex items-start gap-2.5 text-[#4a3525]/90 max-w-xl mx-auto shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-[#d97466] flex-shrink-0 animate-pulse mt-0.5" />
            <div className="font-sans leading-relaxed">
              <b>Alunan Cinta Kasih:</b> Lagu romantis latar belakang sedang diputar secara otomatis untuk menemani senyuman manismu di laman ini, sayang! 🌻✨
            </div>
          </motion.div>
        )}

        {/* Row: Bento Grid Layout */}
        <main className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* LEFT SECTION (Surat Utama & Kotak Mood) - Width 7 on desktop */}
          <section className="col-span-1 md:col-span-7 flex flex-col gap-8">
            
            {/* 1. Main Interactive Love Letter */}
            <div className="w-full">
              <LoveLetter 
                onLetterOpenStateChange={setIsLetterOpen} 
                triggerGlobalKiss={triggerGlobalKiss}
              />
            </div>

            {/* 2. Interactive Mood Checkin */}
            <div className="w-full">
              <MoodHugs />
            </div>

          </section>

          {/* RIGHT SECTION (Penghitung Hari, Kutipan Acak) - Width 5 on desktop */}
          <aside className="col-span-1 md:col-span-5 flex flex-col gap-8">
            
            {/* 1. Relationship duration counter Clock */}
            <div className="w-full">
              <LoveCounter />
            </div>

            {/* 3. Daily Sweet quote block */}
            <div className="bg-white/95 border border-[#f5d6d1] p-5 rounded-2xl w-full shadow-lg relative overflow-hidden flex flex-col gap-4">
              <div className="absolute top-1 right-2 opacity-5 pointer-events-none">
                <Quote className="w-16 h-16 text-[#4a3525]" />
              </div>

              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#d97466] font-bold flex items-center gap-1.5">
                  <MessageSquareHeart className="w-3.5 h-3.5" />
                  Catatan Hangat
                </span>
                
                <button
                  type="button"
                  onClick={rotateQuote}
                  className="p-1 px-3 rounded-full hover:bg-[#fff0f3] text-[#d97466] hover:text-[#4a3525] text-[10px] font-mono transition-all flex items-center gap-1 cursor-pointer border border-[#f5d6d1]"
                  title="Ganti Catatan"
                >
                  <RefreshCw className="w-3 h-3" />
                  Acak Catatan
                </button>
              </div>

              <blockquote className="font-serif italic text-sm sm:text-base text-[#4a3525] leading-relaxed relative pl-4 border-l-2 border-[#d97466]/60 font-medium">
                "{LOVE_QUOTES[currentQuoteIndex]}"
              </blockquote>
              
              <p className="text-[10px] text-right text-[#4a3525]/60 font-mono">
                — dikirim setulus hatiku untukmu 🌹
              </p>
            </div>

          </aside>

        </main>
      </div>

      {/* 4. Footer brand credit info */}
      <footer className="mt-16 pt-6 border-t border-[#f5d6d1] text-center font-mono text-[10px] text-[#4a3525]/60 relative z-10 flex flex-col sm:flex-row justify-between items-center gap-2">
        <p>© 2026 Ruang Dekap Semesta • Khusus Untukmu Terkasih</p>
        <div className="flex gap-4">
          <span className="text-[#d97466] font-bold">Menjagamu seumur hidupku</span>
          <span>•</span>
          <span className="text-[#4a3525]">Kau takkan pernah sendiri</span>
        </div>
      </footer>
    </div>
  );
}
